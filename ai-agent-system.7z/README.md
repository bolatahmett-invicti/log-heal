# 🩺 LogHeal - AI-Powered Error Recovery System

**LogHeal**, ELK (Elasticsearch) loglarını analiz edip otomatik kod düzeltmeleri oluşturan, çok-agentli yapay zeka sistemidir. Streamlit web arayüzü ile log seçimi, AI analizi ve kod değişikliklerini görsel olarak sunar.

## ✨ Öne Çıkan Özellikler

- **🌐 Modern Web Arayüzü**: Streamlit tabanlı, kullanıcı dostu interface
- **🔍 Akıllı Log Filtreleme**: ELK'den gerçek zamanlı hata logları çekme
- **🧠 RAG Tabanlı Kod Analizi**: Büyük codebase'lerde dosya ve sınıf indexleme
- **🤖 Multi-Agent AI**: 5 özelleşmiş agent ile otomatik problem çözme
- **📊 Kod Diff Görüntüleme**: Orijinal ve düzeltilmiş kod karşılaştırması
- **🌿 Git Entegrasyonu**: Otomatik branch oluşturma ve commit
- **⚡ OpenAI GPT-4o**: Güçlü dil modeli ile kod üretimi

## 🏗️ Mimari

```
┌─────────────────────┐
│   Streamlit Web UI  │  👤 Kullanıcı Arayüzü
│  - Log listesi      │     • Log kartları
│  - Log seçimi       │     • Tam log içeriği
│  - Kod diff viewer  │     • 3-tab kod görünümü
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐     ┌──────────────────┐
│   ELK Connector     │────▶│  Log Filter      │
│   - Real ELK        │     │  Agent           │
│   - Mock Data       │     │  (Opsiyonel)     │
└─────────────────────┘     └────────┬─────────┘
                                     │
                    ┌────────────────┴────────────────┐
                    ▼                                 ▼
         ┌─────────────────┐              ┌─────────────────┐
         │ Log Analyzer    │              │ CodebaseProvider│
         │ Agent           │              │ (RAG Indexing)  │
         │ • Parse logs    │              │ • File index    │
         │ • Extract error │              │ • Class index   │
         └────────┬────────┘              └────────┬────────┘
                  │                                 │
                  ▼                                 ▼
         ┌─────────────────┐              ┌─────────────────┐
         │ Error Locator   │◀─────────────│  RAG Search     │
         │ Agent           │              │  • Relevant     │
         │ • Find location │              │    files        │
         │ • Root cause    │              │  • Stack trace  │
         └────────┬────────┘              │    matching     │
                  │                       └─────────────────┘
                  ▼
         ┌─────────────────┐
         │ Solution        │
         │ Architect Agent │
         │ • Design fix    │
         │ • Best practice │
         └────────┬────────┘
                  │
                  ▼
         ┌─────────────────┐
         │ Code Generator  │
         │ Agent           │
         │ • Write code    │
         │ • Apply fix     │
         └────────┬────────┘
                  │
                  ▼
         ┌─────────────────┐
         │ Git Manager     │
         │ Agent           │
         │ • Create branch │
         │ • Commit change │
         └─────────────────┘
```

## 📋 Gereksinimler

- **Python 3.13+**
- **Git** (branch ve commit işlemleri için)
- **OpenAI API Key** (GPT-4o modeli için)
- **Elasticsearch 8.x** (opsiyonel - mock veri kullanılabilir)

## 🚀 Hızlı Başlangıç

### 1. Kurulum

```powershell
# Virtual environment oluştur ve aktifleştir
python -m venv .venv
.venv\Scripts\Activate.ps1

# Bağımlılıkları yükle
pip install -r requirements.txt
```

### 2. API Anahtarı Ayarla

```powershell
# OpenAI API anahtarını environment variable olarak ayarla
$env:OPENAI_API_KEY = "sk-proj-..."
```

### 3. Web Arayüzünü Başlat

```powershell
streamlit run app.py
```

Tarayıcınızda `http://localhost:8501` otomatik açılacaktır.

## 🖥️ Web Arayüzü Kullanımı

### Adım 1: ELK Ayarları
Sol sidebar'dan:
- **Mock veri** kullanarak test edin (örnek loglar)
- **Gerçek ELK** için host, port, kullanıcı bilgilerini girin
- **Zaman aralığı** ayarlayın (30-1440 dakika)

### Adım 2: Codebase Ayarları
- Proje yolunuzu belirtin (örn: `C:\Projects\MyApp`)
- RAG otomatik olarak kodunuzu indexleyecek

### Adım 3: Logları Çekin
- **"🔄 Logları Yenile"** veya **"🚀 Logları Çek ve Başla"** butonuna tıklayın
- Loglar sol tarafta kartlar halinde listelenir

### Adım 4: Log Analizi
- Bir log kartı seçin
- **"📄 Tam Log İçeriği"** ile detaylı JSON görüntüleyin
- **"🔧 Analiz Et"** butonuna tıklayın
- AI agent'lar devreye girer (15-60 saniye sürer)

### Adım 5: Sonuçları İnceleyin
- **Analiz Sonuçları**: Branch adı, değiştirilen dosyalar
- **Kod Değişiklikleri**: 3 tab ile görüntüleme
  - 🔍 **Değişiklikler**: Diff formatında
  - 📝 **Orijinal**: Eski kod
  - ✅ **Düzeltilmiş**: Yeni kod

## 💻 Komut Satırı Kullanımı (Eski Yöntem)

CLI hala desteklenmektedir:

```powershell
# Mock veri ile test
python cli.py --mock

# Gerçek ELK ile
python cli.py --elk-host localhost --elk-port 9200 --time-range 120

# Özel repository
python cli.py --mock --repo-path C:\path\to\your\project
```

## 📊 Örnek Çıktı

```
================================================================================
🤖 Multi-Agent Log Fix System Başlatıldı
================================================================================

[2025-11-17 10:30:45] [LogAnalyzer] ELK logları analiz ediliyor...
[2025-11-17 10:30:48] [LogAnalyzer] Analiz tamamlandı: NullPointerException (high)

📊 Analiz Sonucu:
   Hata: NullPointerException
   Severity: high
   Etkilenen dosyalar: UserController.java

[2025-11-17 10:30:48] [SolutionArchitect] 'NullPointerException' için çözüm üretiliyor...
[2025-11-17 10:30:52] [SolutionArchitect] Çözüm önerisi hazır: 2 dosya etkilenecek

💡 Çözüm Önerisi:
   Dependency injection ile UserService enjekte edilmeli ve null check eklenmeli
   Değiştirilecek: UserController.java, UserService.java

[2025-11-17 10:30:52] [CodeGenerator] Kod değişiklikleri oluşturuluyor...
[2025-11-17 10:30:55] [CodeGenerator]   UserController.java düzeltiliyor...
[2025-11-17 10:30:58] [CodeGenerator]   UserService.java düzeltiliyor...
[2025-11-17 10:30:58] [CodeGenerator] 2 dosya düzeltildi

✏️  Kod Değişiklikleri:
   ✓ UserController.java
   ✓ UserService.java

[2025-11-17 10:30:58] [GitManager] Git branch oluşturuluyor...
[2025-11-17 10:30:59] [GitManager] Branch oluşturuldu: fix/nullpointerexception-20251117-103059
[2025-11-17 10:30:59] [GitManager]   UserController.java yazıldı
[2025-11-17 10:30:59] [GitManager]   UserService.java yazıldı
[2025-11-17 10:31:00] [GitManager] Değişiklikler commit edildi

🎉 İşlem Başarılı!
   Branch: fix/nullpointerexception-20251117-103059
   Değiştirilen dosyalar: 2

================================================================================

Sonraki adımlar:
  1. git checkout fix/nullpointerexception-20251117-103059
  2. Değişiklikleri incele
  3. Testleri çalıştır
  4. git push origin fix/nullpointerexception-20251117-103059
  5. Pull request oluştur
```

## 🔄 Agent Workflow Detayları

### 1️⃣ Log Filter Agent (Opsiyonel)
- Belirli hata tiplerini filtreler
- İlgilenilen hataları ayıklar
- Noise'u azaltır

### 2️⃣ Log Analyzer Agent
- ELK loglarını parse eder
- Hata tipini ve mesajını çıkarır
- Stack trace'i analiz eder
- Severity seviyesi belirler
- Timestamp ve servis bilgilerini toplar

### 3️⃣ Error Locator Agent (RAG Destekli)
- **CodebaseProvider** ile dosya/sınıf indexi kullanır
- Stack trace'ten ilgili dosyaları bulur
- Hata lokasyonunu pinpoint eder
- Root cause analizi yapar
- Relevant code snippet'leri toplar

### 4️⃣ Solution Architect Agent
- Hatayı derinlemesine analiz eder
- Best practice'lere uygun çözüm tasarlar
- Değiştirilmesi gereken dosyaları listeler
- Architecture pattern'leri önerir
- Test stratejileri belirler

### 5️⃣ Code Generator Agent
- Çözümü kod olarak implement eder
- Mevcut kod stilini korur
- Syntax'ı doğrular
- Her dosya için ayrı fix üretir
- Callback ile UI'a kod değişikliklerini bildirir

### 6️⃣ Git Manager Agent
- Benzersiz branch oluşturur (`fix/error-type-timestamp`)
- Değişiklikleri dosyalara yazar
- `.venv`, `node_modules` gibi klasörleri atlar
- Otomatik commit yapar
- Detaylı commit mesajı hazırlar
- Boş commit'leri önler

## 🛠️ Geliştirme

### Yeni Agent Ekleme

```python
from orchestrator import BaseAgent

class MyCustomAgent(BaseAgent):
    def __init__(self):
        super().__init__("MyCustomAgent")
    
    async def my_task(self, input_data):
        prompt = f"My custom prompt: {input_data}"
        response = await self.call_claude(prompt)
        return response
```

### Config Dosyasını Kullanma

```python
import yaml

with open('config.yaml', 'r') as f:
    config = yaml.safe_load(f)

elk_config = config['elk']
agent_config = config['agents']['log_analyzer']
```

## 📝 Best Practices

1. **Test Modda Başlayın**: İlk kullanımda `--mock` ile test edin
2. **Küçük Time Range**: Başlangıçta 15-30 dakika ile başlayın
3. **Manuel Review**: Oluşturulan branch'i mutlaka inceleyin
4. **Test Çalıştırın**: Auto-push yapmadan önce testleri kontrol edin
5. **Yavaş Genişletin**: Sisteme güvendikçe otomasyonu artırın

## 🔒 Güvenlik

- API anahtarları environment variable'da tutun
- ELK şifreleri config dosyasına yazmayın
- Auto-push varsayılan olarak kapalı
- Tüm değişiklikler review gerektiriyor

## 🐛 Sorun Giderme

### "Elasticsearch bağlantı hatası"
```powershell
# ELK servisinin çalıştığını kontrol edin
curl http://localhost:9200

# Firewall kurallarını kontrol edin
# ELK host/port ayarlarını doğrulayın
```

### "OpenAI API hatası"
```powershell
# API anahtarının doğru ayarlandığını kontrol edin
echo $env:OPENAI_API_KEY

# Yeniden ayarlayın
$env:OPENAI_API_KEY = "sk-proj-..."
```

### "Git commit hatası"
```powershell
# Git kullanıcı bilgilerini ayarlayın
cd C:\path\to\your\project
git config user.name "Your Name"
git config user.email "your.email@example.com"
```

### "Loglar listenmiyor"
- Streamlit'i yeniden başlatın (Ctrl+C, sonra tekrar `streamlit run app.py`)
- Tarayıcı cache'ini temizleyin (Ctrl+F5)
- "Always rerun" seçeneğini aktifleştirin

### ".venv dosyaları düzeltiliyor"
- Bu düzeltildi! Artık sadece proje dosyaları işlenir
- `excluded_dirs` listesi virtual environment'ları hariç tutar

## 📈 Roadmap

### v1.1 (Mevcut)
- ✅ Streamlit web arayüzü
- ✅ RAG tabanlı kod analizi
- ✅ OpenAI GPT-4o entegrasyonu
- ✅ Kod diff görüntüleme
- ✅ Virtual environment filtreleme

### v1.2 (Planlanan)
- [ ] **Bulk işlem**: Çoklu log seçimi ve toplu analiz
- [ ] **Log history**: Analiz geçmişi ve öneri tekrarı
- [ ] **Code review**: AI destekli kod inceleme
- [ ] **Undo/Rollback**: Branch silme ve geri alma

### v2.0 (Gelecek)
- [ ] **GitHub/GitLab entegrasyonu**: Otomatik PR oluşturma
- [ ] **Slack/Teams bildirimleri**: Real-time alerting
- [ ] **Test generation**: Otomatik unit test yazımı
- [ ] **Multi-repository**: Microservice desteği
- [ ] **CI/CD pipeline**: Jenkins/GitHub Actions entegrasyonu
- [ ] **Metrics dashboard**: Fix başarı oranları, trend analizi

## 🧪 Test ve Geliştirme

### Yeni Agent Ekleme

```python
from orchestrator import BaseAgent

class MyCustomAgent(BaseAgent):
    def __init__(self):
        super().__init__("MyCustomAgent")
    
    async def analyze(self, input_data: str) -> dict:
        prompt = f"Analyze this: {input_data}"
        response = await self.call_openai(prompt)
        return json.loads(response)
```

### RAG Index Kontrolü

```python
from orchestrator import CodebaseProvider

provider = CodebaseProvider("C:\\path\\to\\project")
print(f"Files indexed: {len(provider.file_index)}")
print(f"Classes indexed: {len(provider.class_index)}")
print(provider.class_index.get("UserController"))
```

## 🤝 Katkıda Bulunma

1. Fork yapın
2. Feature branch oluşturun (`git checkout -b feature/amazing-feature`)
3. Değişikliklerinizi commit edin (`git commit -m 'Add amazing feature'`)
4. Branch'i push edin (`git push origin feature/amazing-feature`)
5. Pull Request açın

## 📄 Lisans

MIT License

## 🌟 Özellikler ve Teknolojiler

| Teknoloji | Kullanım |
|-----------|----------|
| **Python 3.13** | Core language |
| **Streamlit** | Web UI framework |
| **OpenAI GPT-4o** | AI code generation |
| **Elasticsearch** | Log ingestion |
| **asyncio** | Async operations |
| **aiohttp** | HTTP client |
| **Git** | Version control |

## ⚠️ Önemli Notlar

> **🔴 Production Uyarısı**: Bu sistem AI ile otomatik kod üretir. Üretilen kodlar **mutlaka incelenmeli** ve **testler çalıştırılmalıdır**. Direkt production'a push **yapmayın**!

> **💡 İpucu**: İlk kullanımda **mock veri** ile test edin, sistemi tanıyın, sonra gerçek ELK'ye geçin.

> **🔒 Güvenlik**: API anahtarları asla kod içinde saklamayın, environment variable kullanın.

---

**LogHeal** ile hata loglarınızı otomatik iyileştirin! 🩺✨
