"""
AI Agent System - Web Arayüzü
Streamlit ile ELK log analizi ve otomatik fix sistemi
"""

import streamlit as st
import asyncio
import json
import os
from datetime import datetime
from elk_connector import create_elk_connector
from orchestrator import Orchestrator
import difflib

# Sayfa yapılandırması
st.set_page_config(
    page_title="AI Agent System",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# CSS stilleri
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        text-align: center;
        padding: 1rem 0;
    }
    .log-card {
        padding: 1rem;
        border-radius: 0.5rem;
        border: 1px solid #ddd;
        margin: 0.5rem 0;
        background-color: #f8f9fa;
    }
    .log-card:hover {
        background-color: #e9ecef;
        border-color: #1f77b4;
    }
    .error-badge {
        background-color: #dc3545;
        color: white;
        padding: 0.25rem 0.5rem;
        border-radius: 0.25rem;
        font-size: 0.875rem;
    }
    .success-badge {
        background-color: #28a745;
        color: white;
        padding: 0.25rem 0.5rem;
        border-radius: 0.25rem;
        font-size: 0.875rem;
    }
    .info-box {
        padding: 1rem;
        border-radius: 0.5rem;
        background-color: #e7f3ff;
        border-left: 4px solid #1f77b4;
        margin: 1rem 0;
    }
    .diff-added {
        background-color: #d4edda;
        color: #155724;
    }
    .diff-removed {
        background-color: #f8d7da;
        color: #721c24;
    }
</style>
""", unsafe_allow_html=True)


def init_session_state():
    """Session state başlatma"""
    if 'elk_logs' not in st.session_state:
        st.session_state.elk_logs = []
    if 'selected_log' not in st.session_state:
        st.session_state.selected_log = None
    if 'analysis_result' not in st.session_state:
        st.session_state.analysis_result = None
    if 'code_changes' not in st.session_state:
        st.session_state.code_changes = {}
    if 'processing' not in st.session_state:
        st.session_state.processing = False


def fetch_elk_logs():
    """ELK'den logları çeker"""
    with st.spinner("🔍 ELK'den loglar çekiliyor..."):
        elk = create_elk_connector(
            use_mock=st.session_state.get('use_mock', False),
            host=st.session_state.get('elk_host', 'localhost'),
            port=int(st.session_state.get('elk_port', 9200)),
            username=st.session_state.get('elk_username'),
            password=st.session_state.get('elk_password')
        )
        
        if elk.connect():
            logs = elk.fetch_error_logs(
                time_range_minutes=int(st.session_state.get('time_range', 180))
            )
            st.session_state.elk_logs = logs
            if logs:
                st.success(f"✅ {len(logs)} adet log bulundu")
                # Debug: İlk log'un field'larını göster
                if len(logs) > 0:
                    st.write("Debug - İlk log keys:", list(logs[0].keys()))
            else:
                st.warning("⚠️ Hiç log bulunamadı")
        else:
            st.error("❌ ELK'ye bağlanılamadı")


def display_log_card(log, index):
    """Log kartı görüntüler"""
    # Kart container
    with st.container():
        # Seçili mi kontrol et
        is_selected = (st.session_state.selected_log is not None and 
                      st.session_state.selected_log.get('message') == log.get('message'))
        
        border_color = "#1f77b4" if is_selected else "#ddd"
        bg_color = "#e7f3ff" if is_selected else "#f8f9fa"
        
        # Log field'larını al (farklı field adları olabilir)
        service = log.get('service', log.get('service.name', log.get('app', log.get('application', 'Service'))))
        msg = log.get('error_message', log.get('message', log.get('msg', log.get('text', str(log.get('exception', {}).get('message', 'Log mesajı yok'))))))
        timestamp = log.get('timestamp', log.get('@timestamp', log.get('time', 'N/A')))
        level = log.get('level', log.get('severity', log.get('log.level', 'ERROR')))
        
        # Kart HTML
        st.markdown(f"""
        <div style="padding: 1rem; border-radius: 0.5rem; border: 2px solid {border_color}; 
                    margin: 0.5rem 0; background-color: {bg_color};">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div style="flex: 1;">
                    <strong>📌 {service}</strong><br>
                    <span style="color: #666;">{str(msg)[:80]}...</span>
                </div>
                <div style="text-align: right; min-width: 150px;">
                    <span style="background-color: #dc3545; color: white; padding: 0.25rem 0.5rem; 
                                 border-radius: 0.25rem; font-size: 0.75rem;">{level}</span><br>
                    <small style="color: #666;">{str(timestamp)[:19]}</small>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)
        
        # Tam log içeriği - expander ile
        with st.expander("📄 Tam Log İçeriği", expanded=False):
            st.json(log)
        
        # Buton
        if st.button("🔧 Analiz Et", key=f"analyze_{index}", use_container_width=True):
            st.session_state.selected_log = log
            st.rerun()


async def process_log_async(log, repo_path):
    """Seçilen logu işler"""
    orchestrator = Orchestrator(
        repo_path=repo_path,
        enable_rag=True
    )
    
    # Kod değişikliklerini kaydetmek için callback
    def save_code_changes(filename, original, fixed):
        if 'code_changes' not in st.session_state:
            st.session_state.code_changes = {}
        st.session_state.code_changes[filename] = {
            'original': original,
            'fixed': fixed
        }
    
    result = await orchestrator.process_logs([log], {}, save_changes_callback=save_code_changes)
    return result


def show_code_diff(original, fixed, filename):
    """Kod değişikliklerini diff olarak gösterir"""
    st.markdown(f"### 📄 {filename}")
    
    # Tab'lar oluştur
    tab1, tab2, tab3 = st.tabs(["🔍 Değişiklikler", "📝 Orijinal", "✅ Düzeltilmiş"])
    
    with tab1:
        # Diff göster
        diff = difflib.unified_diff(
            original.splitlines(keepends=True),
            fixed.splitlines(keepends=True),
            fromfile=f'{filename} (Orijinal)',
            tofile=f'{filename} (Düzeltilmiş)',
            lineterm=''
        )
        
        diff_text = ''.join(diff)
        if diff_text:
            st.code(diff_text, language='diff')
        else:
            st.info("Değişiklik yok")
    
    with tab2:
        st.code(original, language='python' if filename.endswith('.py') else 'csharp' if filename.endswith('.cs') else 'java')
    
    with tab3:
        st.code(fixed, language='python' if filename.endswith('.py') else 'csharp' if filename.endswith('.cs') else 'java')


def main():
    """Ana uygulama"""
    init_session_state()
    
    # Başlık
    st.markdown('<div class="main-header">🤖 AI Agent System</div>', unsafe_allow_html=True)
    st.markdown("---")
    
    # Sidebar - Ayarlar
    with st.sidebar:
        st.header("⚙️ Ayarlar")
        
        # ELK Bağlantısı
        st.subheader("🔌 ELK Bağlantısı")
        use_mock = st.checkbox("Mock veri kullan (Test)", value=False)
        st.session_state.use_mock = use_mock
        
        if not use_mock:
            elk_host = st.text_input("ELK Host", value=os.getenv("ELK_HOST", "localhost"))
            elk_port = st.text_input("ELK Port", value=os.getenv("ELK_PORT", "9200"))
            elk_username = st.text_input("Username (opsiyonel)", value=os.getenv("ELK_USERNAME", ""))
            elk_password = st.text_input("Password (opsiyonel)", type="password", value=os.getenv("ELK_PASSWORD", ""))
            
            st.session_state.elk_host = elk_host
            st.session_state.elk_port = elk_port
            st.session_state.elk_username = elk_username if elk_username else None
            st.session_state.elk_password = elk_password if elk_password else None
        
        time_range = st.slider("Zaman Aralığı (dakika)", 30, 1440, 180)
        st.session_state.time_range = time_range
        
        st.markdown("---")
        
        # Codebase Ayarları
        st.subheader("📂 Codebase")
        repo_path = st.text_input(
            "Proje Yolu",
            value=r"C:\Users\AhmetBolat\Projects\Claude\TestSystem"
        )
        st.session_state.repo_path = repo_path
        
        st.markdown("---")
        
        # Logları Çek
        if st.button("🔄 Logları Yenile", use_container_width=True):
            fetch_elk_logs()
    
    # Ana İçerik
    if not st.session_state.elk_logs:
        # İlk açılış ekranı
        st.markdown("""
        <div class="info-box">
            <h3>👋 Hoş Geldiniz!</h3>
            <p>ELK loglarını analiz etmek ve otomatik düzeltmeler oluşturmak için:</p>
            <ol>
                <li>Sol taraftaki ayarları yapılandırın</li>
                <li>"Logları Yenile" butonuna tıklayın</li>
                <li>Listeden bir log seçin</li>
                <li>Analiz sonuçlarını inceleyin ve düzeltmeleri görün</li>
            </ol>
        </div>
        """, unsafe_allow_html=True)
        
        if st.button("🚀 Logları Çek ve Başla", type="primary"):
            fetch_elk_logs()
            st.rerun()
    
    else:
        # İki sütun: Log Listesi ve Detaylar
        col_list, col_detail = st.columns([1, 2])
        
        with col_list:
            st.subheader(f"📋 ELK Logları ({len(st.session_state.elk_logs)})")
            
            # Debug bilgisi
            if len(st.session_state.elk_logs) == 0:
                st.warning("⚠️ Hiç log bulunamadı!")
            else:
                st.info(f"✅ {len(st.session_state.elk_logs)} log listeleniyor")
            
            # Logları listele
            for idx, log in enumerate(st.session_state.elk_logs):
                display_log_card(log, idx)
                st.markdown("---")
        
        with col_detail:
            if st.session_state.selected_log:
                st.subheader("🔍 Log Detayları")
                
                # Seçilen logu göster
                selected = st.session_state.selected_log
                
                # Log bilgileri
                info_col1, info_col2 = st.columns(2)
                with info_col1:
                    st.metric("Hata Tipi", selected.get('level', 'N/A'))
                    st.metric("Servis", selected.get('service', 'N/A'))
                with info_col2:
                    st.metric("Zaman", selected.get('timestamp', selected.get('@timestamp', 'N/A')))
                
                # Log mesajı
                st.text_area("Mesaj", selected.get('message', 'N/A'), height=100, disabled=True)
                
                # JSON görünüm
                with st.expander("📄 Tam Log (JSON)"):
                    st.json(selected)
                
                st.markdown("---")
                
                # Analiz butonu
                if not st.session_state.processing:
                    if st.button("🤖 AI Analizi Başlat", type="primary", use_container_width=True):
                        st.session_state.processing = True
                        st.rerun()
                
                # Analiz işlemi
                if st.session_state.processing:
                    with st.spinner("🔄 AI agent'lar çalışıyor... (Bu biraz zaman alabilir)"):
                        try:
                            # Async fonksiyonu çalıştır
                            loop = asyncio.new_event_loop()
                            asyncio.set_event_loop(loop)
                            result = loop.run_until_complete(
                                process_log_async(
                                    selected,
                                    st.session_state.repo_path
                                )
                            )
                            loop.close()
                            
                            st.session_state.analysis_result = result
                            st.session_state.processing = False
                            st.success("✅ Analiz tamamlandı!")
                            st.rerun()
                            
                        except Exception as e:
                            st.error(f"❌ Hata oluştu: {str(e)}")
                            st.session_state.processing = False
                
                # Sonuçları göster
                if st.session_state.analysis_result and not st.session_state.processing:
                    result = st.session_state.analysis_result
                    
                    st.markdown("---")
                    st.subheader("📊 Analiz Sonuçları")
                    
                    if result.success:
                        st.success(f"🎉 Başarılı! Branch: `{result.branch_name}`")
                        
                        # Değiştirilen dosyalar
                        if result.files_changed:
                            st.markdown("### 📝 Değiştirilen Dosyalar")
                            
                            for file_path in result.files_changed:
                                st.markdown(f"- ✅ `{file_path}`")
                        
                        # Commit mesajı
                        with st.expander("💬 Commit Mesajı"):
                            st.code(result.commit_message)
                        
                        # Kod değişiklikleri (eğer varsa)
                        if hasattr(st.session_state, 'code_changes') and st.session_state.code_changes:
                            st.markdown("---")
                            st.subheader("🔧 Kod Değişiklikleri")
                            
                            for filename, changes in st.session_state.code_changes.items():
                                if 'original' in changes and 'fixed' in changes:
                                    show_code_diff(
                                        changes['original'],
                                        changes['fixed'],
                                        filename
                                    )
                    else:
                        st.warning("⚠️ İşlem tamamlanamadı. Detaylar için loglara bakın.")
            
            else:
                st.info("👈 Lütfen soldan bir log seçin")


if __name__ == "__main__":
    main()
