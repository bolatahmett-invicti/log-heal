#!/usr/bin/env python3
"""
AI Agent System CLI
ELK loglarını analiz edip otomatik fix oluşturur
"""

import asyncio
import argparse
import sys
import os
from pathlib import Path

from orchestrator import Orchestrator
from elk_connector import create_elk_connector


def load_file_contents(file_paths: list) -> dict:
    """Dosya içeriklerini yükler"""
    contents = {}
    
    for path in file_paths:
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as f:
                contents[path] = f.read()
            print(f"✓ Yüklendi: {path}")
        else:
            print(f"⚠ Dosya bulunamadı: {path}")
    
    return contents


async def run_analysis(args):
    """Ana analiz workflow'unu çalıştır"""
    
    # ELK'ye bağlan
    print("\n🔌 ELK'ye bağlanılıyor...")
    elk = create_elk_connector(
        use_mock=args.mock,
        host=args.elk_host,
        port=args.elk_port,
        username=args.elk_user,
        password=args.elk_password
    )
    
    if not elk.connect():
        print("❌ ELK'ye bağlanılamadı!")
        return 1
    
    # Logları çek
    print(f"\n📥 Son {args.time_range} dakikadan loglar çekiliyor...")
    elk_logs = elk.get_recent_errors(minutes=args.time_range)
    
    if not elk_logs or elk_logs.strip() == "":
        print("ℹ️  Hata logu bulunamadı.")
        return 0
    
    print(f"✓ Loglar alındı ({len(elk_logs)} karakter)")
    
    # Dosya içeriklerini yükle
    file_contents = {}
    if args.files:
        print(f"\n📂 Dosyalar yükleniyor...")
        file_contents = load_file_contents(args.files)
    
    # Orchestrator'ı başlat
    orchestrator = Orchestrator(repo_path=args.repo_path)
    
    # Analizi çalıştır
    result = await orchestrator.process_logs(elk_logs, file_contents)
    
    if result.success:
        print(f"\n✅ Fix başarıyla oluşturuldu!")
        print(f"\nSonraki adımlar:")
        print(f"  1. git checkout {result.branch_name}")
        print(f"  2. Değişiklikleri incele")
        print(f"  3. Testleri çalıştır")
        print(f"  4. git push origin {result.branch_name}")
        print(f"  5. Pull request oluştur")
        return 0
    else:
        print(f"\n❌ Fix oluşturulamadı!")
        return 1


def main():
    parser = argparse.ArgumentParser(
        description='AI Agent System - ELK Log Analyzer ve Auto-Fix',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Örnekler:
  # Mock modda çalıştır (test için)
  python cli.py --mock
  
  # Gerçek ELK'den logları çek
  python cli.py --elk-host localhost --elk-port 9200
  
  # Belirli dosyaları analiz et
  python cli.py --mock --files UserController.java UserService.java
  
  # Son 120 dakikadan logları çek
  python cli.py --elk-host elk.example.com --time-range 120
        """
    )
    
    # ELK ayarları
    elk_group = parser.add_argument_group('ELK Ayarları')
    elk_group.add_argument('--mock', action='store_true',
                          help='Mock ELK kullan (test modu)')
    elk_group.add_argument('--elk-host', default='localhost',
                          help='Elasticsearch host (varsayılan: localhost)')
    elk_group.add_argument('--elk-port', type=int, default=9200,
                          help='Elasticsearch port (varsayılan: 9200)')
    elk_group.add_argument('--elk-user', help='Elasticsearch kullanıcı adı')
    elk_group.add_argument('--elk-password', help='Elasticsearch şifresi')
    elk_group.add_argument('--time-range', type=int, default=60,
                          help='Son kaç dakikadan logları çek (varsayılan: 60)')
    
    # Dosya ayarları
    file_group = parser.add_argument_group('Dosya Ayarları')
    file_group.add_argument('--files', nargs='+',
                           help='Analiz edilecek dosyalar')
    file_group.add_argument('--repo-path', default='.',
                           help='Git repository yolu (varsayılan: .)')
    
    args = parser.parse_args()
    
    # Async çalıştır
    try:
        exit_code = asyncio.run(run_analysis(args))
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\n\n⚠️  İşlem kullanıcı tarafından iptal edildi")
        sys.exit(130)
    except Exception as e:
        print(f"\n❌ Beklenmeyen hata: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
