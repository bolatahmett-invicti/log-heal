#!/usr/bin/env python3
"""
Demo Script - AI Agent System'i test eder
"""

import asyncio
import os
from orchestrator import Orchestrator
from elk_connector import MockELKConnector


async def demo():
    """Demo workflow"""
    
    print("""
    ╔═══════════════════════════════════════════════════════════╗
    ║                                                           ║
    ║         🤖 AI Multi-Agent System Demo                    ║
    ║                                                           ║
    ║  Bu demo, sistemin nasıl çalıştığını gösterir            ║
    ║                                                           ║
    ╚═══════════════════════════════════════════════════════════╝
    """)
    
    input("Demo'ya başlamak için Enter'a basın...")
    
    # 1. ELK Mock
    print("\n" + "="*80)
    print("ADIM 1: Mock ELK'den örnek hata logları çekiliyor...")
    print("="*80)
    
    elk = MockELKConnector()
    elk.connect()
    elk_logs = elk.get_recent_errors()
    
    print(f"\n✓ {len(elk_logs)} karakter log verisi alındı")
    print("\nÖrnek log parçası:")
    print("-" * 80)
    print(elk_logs[:500] + "...")
    print("-" * 80)
    
    input("\nDevam etmek için Enter'a basın...")
    
    # 2. Örnek dosya içerikleri
    print("\n" + "="*80)
    print("ADIM 2: Örnek kaynak kod dosyaları yükleniyor...")
    print("="*80)
    
    sample_files = {
        "UserController.java": """package com.example.controller;

import com.example.service.UserService;
import com.example.model.User;

public class UserController {
    private UserService userService;
    
    public UserController() {
        // UserService dependency injection eksik!
    }
    
    public User getUser(Long id) {
        // Burada userService null olduğu için NullPointerException oluşur
        return userService.findById(id);
    }
    
    public void updateUser(Long id, User userData) {
        User existingUser = userService.findById(id);
        existingUser.setName(userData.getName());
        existingUser.setEmail(userData.getEmail());
        userService.save(existingUser);
    }
}
""",
        "UserService.java": """package com.example.service;

import com.example.model.User;
import com.example.repository.UserRepository;

public class UserService {
    private UserRepository userRepository;
    
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    
    public User findById(Long id) {
        return userRepository.findById(id).orElse(null);
    }
    
    public void save(User user) {
        userRepository.save(user);
    }
}
"""
    }
    
    print("\n✓ 2 kaynak dosya yüklendi:")
    for filename in sample_files.keys():
        print(f"  - {filename}")
    
    input("\nDevam etmek için Enter'a basın...")
    
    # 3. Orchestrator
    print("\n" + "="*80)
    print("ADIM 3: Multi-Agent sistem başlatılıyor...")
    print("="*80)
    print("\nAgent'lar sırasıyla çalışacak:")
    print("  1. 🔍 Log Analyzer - Logları analiz edecek")
    print("  2. 💡 Solution Architect - Çözüm önerecek")
    print("  3. ✏️  Code Generator - Kodu düzeltecek")
    print("  4. 🌿 Git Manager - Branch oluşturacak")
    
    input("\nAnalizi başlatmak için Enter'a basın...")
    
    orchestrator = Orchestrator(repo_path=".")
    
    # 4. Analizi çalıştır
    try:
        result = await orchestrator.process_logs(elk_logs, sample_files)
        
        # 5. Sonuç
        print("\n" + "="*80)
        print("DEMO TAMAMLANDI!")
        print("="*80)
        
        if result.success:
            print(f"""
✅ Başarılı!

Oluşturulan Branch: {result.branch_name}
Değiştirilen Dosyalar: {len(result.files_changed)}

Bu demo'da sistem:
1. ✓ ELK loglarını analiz etti
2. ✓ NullPointerException hatasını tespit etti
3. ✓ Dependency Injection çözümü önerdi
4. ✓ Kodu otomatik düzeltti
5. ✓ Git branch oluşturdu

Gerçek kullanımda:
- Gerçek ELK stack'inize bağlanabilir
- Gerçek kod dosyalarınızı düzeltir
- Otomatik PR oluşturabilir (opsiyonel)

Daha fazla bilgi için: python cli.py --help
            """)
        else:
            print("\n❌ Demo sırasında bir hata oluştu")
        
    except Exception as e:
        print(f"\n❌ Demo hatası: {e}")
        import traceback
        traceback.print_exc()
    
    print("\n" + "="*80)


if __name__ == "__main__":
    try:
        asyncio.run(demo())
    except KeyboardInterrupt:
        print("\n\n⚠️  Demo iptal edildi")
