"""
ELK (Elasticsearch) entegrasyonu
Gerçek ELK stack'inden logları çeker
"""

from typing import List, Dict, Any
from datetime import datetime, timedelta
import json


class ELKConnector:
    """Elasticsearch'ten log çeker"""
    
    def __init__(self, host: str = "localhost", port: int = 9200, 
                 username: str = None, password: str = None):
        """
        Args:
            host: Elasticsearch host
            port: Elasticsearch port
            username: Authentication username
            password: Authentication password
        """
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.es_client = None
    
    def connect(self):
        """Elasticsearch'e bağlan"""
        try:
            from elasticsearch import Elasticsearch
            
            if self.username and self.password:
                self.es_client = Elasticsearch(
                    [f"http://{self.host}:{self.port}"],
                    basic_auth=(self.username, self.password)
                )
            else:
                self.es_client = Elasticsearch(
                    [f"http://{self.host}:{self.port}"]
                )
            
            # Bağlantıyı test et
            info = self.es_client.info()
            print(f"✓ Elasticsearch'e bağlanıldı: {info['version']['number']}")
            return True
            
        except Exception as e:
            print(f"✗ Elasticsearch bağlantı hatası: {e}")
            return False
    
    def fetch_error_logs(self, 
                        index: str = "app-logs**",
                        time_range_minutes: int = 60,
                        severity: List[str] = None,
                        limit: int = 100) -> List[Dict[str, Any]]:
        """
        Hata loglarını çeker
        
        Args:
            index: Elasticsearch index pattern
            time_range_minutes: Son kaç dakikadan logları çek
            severity: Log seviyeleri (ERROR, CRITICAL, etc.)
            limit: Maksimum log sayısı
        """
        if not self.es_client:
            raise Exception("Elasticsearch'e bağlı değil. Önce connect() çağırın.")
        
        if severity is None:
            severity = ["ERROR", "CRITICAL", "FATAL"]
        
        # Zaman aralığı
        time_from = datetime.now() - timedelta(minutes=time_range_minutes)
        
        # Query oluştur
        query = {
            "query": {
                "bool": {
                    "must": [
                        {
                            "match_phrase": {
                                "level": "ERROR"
                            }
                        }
                    ]
                }
            },
            "size": limit
        }
        
        try:
            response = self.es_client.search(index=index, body=query)

            logs = []
            for hit in response['hits']['hits']:
                logs.append(hit['_source'])
            
            print(f"✓ {len(logs)} hata logu çekildi")
            return logs
            
        except Exception as e:
            print(f"✗ Log çekme hatası: {e}")
            return []
    
    def format_logs_for_analysis(self, logs: List[Dict[str, Any]]) -> str:
        """Logları AI analizi için formatlar"""
        formatted = []
        
        for log in logs:
            formatted.append(json.dumps(log, indent=2, ensure_ascii=False))
        
        return "\n\n---\n\n".join(formatted)
    
    def get_recent_errors(self, minutes: int = 60) -> str:
        """Son X dakikadaki hataları çeker ve formatlar"""
        if not self.es_client:
            self.connect()
        
        logs = self.fetch_error_logs(time_range_minutes=minutes)
        return self.format_logs_for_analysis(logs)


class MockELKConnector:
    """Test için mock ELK connector"""
    
    def connect(self):
        print("✓ Mock ELK connector (test modu)")
        return True
    
    def fetch_error_logs(self, 
                        index: str = "app-logs**",
                        time_range_minutes: int = 60,
                        severity: List[str] = None,
                        limit: int = 100) -> List[Dict[str, Any]]:
        """Örnek hata logları döner"""
        sample_logs = [
            {
                "timestamp": "2025-11-17T10:30:45.123Z",
                "level": "ERROR",
                "service": "user-service",
                "message": "NullPointerException in UserController",
                "exception": {
                    "class": "java.lang.NullPointerException",
                    "message": "Cannot invoke method on null object",
                    "stacktrace": [
                        "at com.example.UserController.getUser(UserController.java:45)",
                        "at com.example.UserService.findById(UserService.java:23)"
                    ]
                },
                "context": {
                    "file": "src/main/java/com/example/UserController.java",
                    "line": 45,
                    "method": "getUser"
                }
            },
            {
                "timestamp": "2025-11-17T10:35:12.456Z",
                "level": "ERROR",
                "service": "payment-service",
                "message": "Database connection timeout",
                "exception": {
                    "class": "java.sql.SQLException",
                    "message": "Connection timeout after 30s",
                    "stacktrace": [
                        "at com.example.PaymentService.processPayment(PaymentService.java:78)",
                        "at com.example.DatabasePool.getConnection(DatabasePool.java:34)"
                    ]
                },
                "context": {
                    "file": "src/main/java/com/example/PaymentService.java",
                    "line": 78,
                    "method": "processPayment"
                }
            }
        ]
        
        print(f"✓ Mock: {len(sample_logs)} örnek log döndürüldü")
        return sample_logs
    
    def get_recent_errors(self, minutes: int = 60) -> str:
        """Örnek hata loglarını formatlanmış olarak döner"""
        logs = self.fetch_error_logs(time_range_minutes=minutes)
        return "\n\n---\n\n".join([json.dumps(log, indent=2, ensure_ascii=False) for log in logs])


def create_elk_connector(use_mock: bool = True, **kwargs) -> ELKConnector:
    """
    ELK connector factory
    
    Args:
        use_mock: True ise mock connector döner (test için)
        **kwargs: Gerçek ELK için bağlantı parametreleri
    """
    if use_mock:
        return MockELKConnector()
    else:
        return ELKConnector(**kwargs)
